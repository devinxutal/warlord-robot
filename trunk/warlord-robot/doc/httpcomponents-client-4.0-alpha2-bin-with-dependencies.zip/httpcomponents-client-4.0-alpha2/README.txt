Apache HttpComponents Client
============================
Welcome to the HttpClient component of the HttpComponents project.

Visit the project site at
   http://jakarta.apache.org/httpcomponents/
for more information.

